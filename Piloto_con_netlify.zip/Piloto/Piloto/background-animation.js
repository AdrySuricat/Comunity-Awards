export default function startPetalsAnimation() {
  const numPetals = 25;

  for (let i = 0; i < numPetals; i++) {
    const petal = document.createElement("div");
    petal.className = "petal";
    petal.style.left = Math.random() * 100 + "vw";
    petal.style.animationDuration = 5 + Math.random() * 5 + "s";
    petal.style.opacity = Math.random();
    document.body.appendChild(petal);

    setTimeout(() => {
      document.body.removeChild(petal);
    }, 10000);
  }
}