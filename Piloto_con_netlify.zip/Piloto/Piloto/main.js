import { auth, provider, signInWithPopup, onAuthStateChanged, signOut, db, doc, setDoc, getDoc } from './firebase-config.js';

const loginBtn = document.getElementById('login-btn');
const logoutBtn = document.getElementById('logout-btn');
const userProfile = document.getElementById('user-profile');
const voteBtn = document.getElementById('vote-btn');

loginBtn?.addEventListener('click', async () => {
  try {
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    userProfile.innerHTML = `<img src="${user.photoURL}" alt="${user.displayName}" class="w-8 h-8 rounded-full" /> ${user.displayName}`;
    loginBtn.classList.add('hidden');
    logoutBtn.classList.remove('hidden');
    voteBtn.classList.remove('hidden');
  } catch (error) {
    console.error("Error al iniciar sesión:", error);
  }
});

logoutBtn?.addEventListener('click', () => {
  signOut(auth).then(() => {
    userProfile.innerHTML = '';
    loginBtn.classList.remove('hidden');
    logoutBtn.classList.add('hidden');
    voteBtn.classList.add('hidden');
  });
});

onAuthStateChanged(auth, (user) => {
  if (user) {
    userProfile.innerHTML = `<img src="${user.photoURL}" alt="${user.displayName}" class="w-8 h-8 rounded-full" /> ${user.displayName}`;
    loginBtn?.classList.add('hidden');
    logoutBtn?.classList.remove('hidden');
    voteBtn?.classList.remove('hidden');
  } else {
    userProfile.innerHTML = '';
    loginBtn?.classList.remove('hidden');
    logoutBtn?.classList.add('hidden');
    voteBtn?.classList.add('hidden');
  }
});