const categories = [
  {
    id: "best-builder",
    name_en: "Best Builder",
    name_es: "Mejor Constructor",
    description_en: "Awarded to the most talented builder in the community.",
    description_es: "Otorgado al constructor más talentoso de la comunidad."
  },
  {
    id: "best-creator",
    name_en: "Best Content Creator",
    name_es: "Mejor Creador de Contenido",
    description_en: "For the creator with the most engaging content this year.",
    description_es: "Para el creador con el contenido más atractivo del año."
  },
  {
    id: "best-event",
    name_en: "Best Community Event",
    name_es: "Mejor Evento Comunitario",
    description_en: "Recognizing the event that brought players together the most.",
    description_es: "Reconociendo el evento que más unió a los jugadores."
  }
];

function renderCategoryCards(lang = "en") {
  const container = document.getElementById("category-container");
  container.innerHTML = "";
  categories.forEach(category => {
    const card = document.createElement("div");
    card.className = "category-card";
    card.innerHTML = `
      <h2>${lang === "en" ? category.name_en : category.name_es}</h2>
      <p>${lang === "en" ? category.description_en : category.description_es}</p>
      <a href="/vote/${category.id}" target="_blank" class="vote-link">${lang === "en" ? "Vote Now" : "Votar Ahora"}</a>
    `;
    container.appendChild(card);
  });
}

// Detectar idioma y renderizar categorías al cargar
document.addEventListener("DOMContentLoaded", () => {
  const lang = navigator.language.startsWith("es") ? "es" : "en";
  renderCategoryCards(lang);
});