import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import {
  getFirestore,
  collection,
  doc,
  getDoc,
  updateDoc,
  increment,
} from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";
import {
  getAuth,
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
} from "https://www.gstatic.com/firebasejs/10.11.0/firebase-auth.js";

// Firebase config
const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "comunity-awards.firebaseapp.com",
  projectId: "comunity-awards",
  storageBucket: "comunity-awards.appspot.com",
  messagingSenderId: "TU_SENDER_ID",
  appId: "TU_APP_ID",
};

// Inicializar Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

// Autenticación
let currentUser = null;
onAuthStateChanged(auth, (user) => {
  if (user) {
    currentUser = user;
    document.getElementById("user-info").textContent = `Hola, ${user.displayName}`;
  } else {
    currentUser = null;
    document.getElementById("user-info").textContent = "No has iniciado sesión";
  }
});

document.getElementById("google-login").addEventListener("click", () => {
  signInWithPopup(auth, provider);
});

// Votación
async function voteForNominee(categoryId, nomineeId) {
  if (!currentUser) {
    alert("Debes iniciar sesión para votar.");
    return;
  }

  const voteRef = doc(db, `votes-${categoryId}`, nomineeId);
  const voteSnap = await getDoc(voteRef);

  if (voteSnap.exists()) {
    await updateDoc(voteRef, {
      votes: increment(1),
    });
    alert("¡Tu voto ha sido registrado!");
  } else {
    alert("Error: el nominado no existe.");
  }
}

// Asignar listeners a los botones
document.querySelectorAll(".vote-button").forEach((button) => {
  button.addEventListener("click", (e) => {
    const category = e.target.dataset.category;
    const nominee = e.target.dataset.nominee;
    voteForNominee(category, nominee);
  });
});