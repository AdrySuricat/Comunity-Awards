// Mostrar contenido principal al hacer clic en "Continuar"
document.getElementById("continue-btn").addEventListener("click", () => {
  document.getElementById("intro-screen").style.display = "none";
  document.getElementById("main-content").style.display = "block";
});

// Manejo del botón de sonido ambiental
let ambientAudio = document.getElementById("ambient-audio");
let soundToggle = document.getElementById("sound-toggle");
let isMuted = false;

soundToggle.addEventListener("click", () => {
  isMuted = !isMuted;
  ambientAudio.muted = isMuted;
  soundToggle.innerText = isMuted ? "🔇" : "🔊";
});

// Mostrar acceso a votaciones si está logueado
function showVotingAccess() {
  document.getElementById("voting-access").style.display = "block";
}