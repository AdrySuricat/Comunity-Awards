// Inicializa Firebase Auth
const auth = firebase.auth();

// Función de inicio de sesión con Google
function loginWithGoogle() {
  const provider = new firebase.auth.GoogleAuthProvider();
  auth.signInWithPopup(provider)
    .then((result) => {
      const user = result.user;
      console.log("Usuario conectado:", user.displayName);
      document.getElementById("login-btn").style.display = "none";
      // Mostrar acceso a votaciones si está logueado
      showVotingAccess();
    })
    .catch((error) => {
      console.error("Error en inicio de sesión:", error.message);
    });
}

// Verifica si ya está autenticado
auth.onAuthStateChanged((user) => {
  if (user) {
    document.getElementById("login-btn").style.display = "none";
    showVotingAccess();
  }
});