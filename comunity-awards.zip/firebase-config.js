
// Firebase config del usuario
const firebaseConfig = {
  apiKey: "AIzaSyAujxSBFiHW8BgtjBFQM0a1O9IEJQQV088",
  authDomain: "comunity-awards.firebaseapp.com",
  projectId: "comunity-awards",
  storageBucket: "comunity-awards.firebasestorage.app",
  messagingSenderId: "593964017438",
  appId: "1:593964017438:web:41e0c491123e8a1fd28b0f",
  measurementId: "G-9P736TQ863"
};
