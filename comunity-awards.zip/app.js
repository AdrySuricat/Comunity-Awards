
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-app.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-firestore.js";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/10.11.0/firebase-auth.js";

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

document.getElementById("app").innerHTML = '<button id="loginBtn">Iniciar sesión con Google</button>';

document.getElementById("loginBtn").addEventListener("click", async () => {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    const user = result.user;
    document.getElementById("app").innerHTML = `<h1>Hola, ${user.displayName}!</h1><p>Ya puedes votar.</p>`;
  } catch (error) {
    console.error("Error de inicio de sesión", error);
  }
});
